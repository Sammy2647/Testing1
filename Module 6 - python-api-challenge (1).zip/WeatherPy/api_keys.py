# OpenWeatherMap API Key
weather_api_key = "8af3554ca164ad6089d6ca5219a00682"

# Geoapify API Key
geoapify_key = "4aa5b8435c8447a8ad9fa30ded2e6834"
